# Future Roadmap

RAG
Azure AI Foundry
LangGraph
MCP
Vector DB
File Upload
Background Jobs
Notifications
Payments
Multi-tenancy
