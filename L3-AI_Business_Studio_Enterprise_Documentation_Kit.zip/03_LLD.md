# Low Level Design

Modules:
- auth
- users
- providers
- ai
- prompts
- history
- admin

Each module contains:
router
service
repository
schemas
models
tests
