# UI System

Use an 8px spacing grid.
Typography hierarchy.
Reusable cards.
Consistent iconography.
Dark/Light themes.
Animated but subtle interactions.
No clutter.
