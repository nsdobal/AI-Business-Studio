# Database

Tables:
Users
Roles
UserApiKeys
ApiProviders
AIModels
Prompts
IdeaRequests
IdeaResponses
ConversationHistory
AuditLogs
ApplicationSettings

Rules:
- UUID primary keys preferred
- CreatedAt/UpdatedAt
- Soft delete where appropriate
- Foreign keys
- Index search columns
