# Azure

Deploy:
Ubuntu VM
Docker Compose
Nginx
Azure SQL

Future:
AKS
Azure Key Vault
Application Insights
Azure Front Door
