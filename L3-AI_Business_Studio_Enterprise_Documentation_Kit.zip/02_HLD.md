# High Level Design

Frontend: React + TypeScript
Backend: FastAPI
Database: Azure SQL
Deployment: Azure VM + Docker + Nginx

Architecture:
UI -> API -> Services -> Repositories -> SQL

Cross-cutting:
Logging
Security
Validation
Configuration
Caching (future)
