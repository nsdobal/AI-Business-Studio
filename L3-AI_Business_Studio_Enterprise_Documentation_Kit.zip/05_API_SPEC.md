# API

Auth
POST /register
POST /login
POST /refresh
POST /logout

Profile
GET /profile
PUT /profile

Providers
GET /providers
GET /models
POST /apikey
PUT /apikey
DELETE /apikey

AI
POST /generate
GET /history
DELETE /history/{id}
