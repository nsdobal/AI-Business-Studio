# Read First

This workspace is intended to guide Cursor to build a production-quality AI SaaS application.

Recommended generation order:
1. Read AGENTS.md
2. Read PRD
3. Read HLD
4. Read LLD
5. Read DATABASE
6. Read API
7. Generate Phase 1
8. Verify
9. Generate Phase 2
10. Verify
11. Generate Phase 3
