# Security

JWT
Refresh Tokens
bcrypt
AES-256 encrypted API keys
Rate limiting
Validation
Parameterized ORM queries
HTTPS
Never log secrets
