# ERD

Users 1:N IdeaRequests
Users 1:N UserApiKeys
IdeaRequests 1:1 IdeaResponses
