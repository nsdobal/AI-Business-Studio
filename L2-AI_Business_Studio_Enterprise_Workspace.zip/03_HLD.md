# High Level Design

React -> FastAPI -> Service Layer -> Repository -> Azure SQL

Docker + Nginx on Azure VM.
