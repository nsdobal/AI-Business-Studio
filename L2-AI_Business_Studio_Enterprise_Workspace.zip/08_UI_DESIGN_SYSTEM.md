# UI Design System

Typography, spacing, 8px grid, reusable components, light/dark theme.
