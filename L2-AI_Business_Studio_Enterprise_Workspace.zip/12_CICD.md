# CI/CD

GitHub Actions or Azure DevOps.
Lint -> Test -> Build -> Deploy.
