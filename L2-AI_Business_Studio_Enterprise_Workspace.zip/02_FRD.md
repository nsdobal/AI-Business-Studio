# Functional Requirements

Authentication, AI provider management, business idea generation, history, admin, profile, settings.
