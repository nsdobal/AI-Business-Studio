# Security

JWT, Refresh Tokens, bcrypt, AES-256, rate limiting, validation, CORS.
