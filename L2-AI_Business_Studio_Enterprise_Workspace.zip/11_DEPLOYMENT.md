# Deployment

Azure VM + Azure SQL + Docker Compose + Nginx + HTTPS.
