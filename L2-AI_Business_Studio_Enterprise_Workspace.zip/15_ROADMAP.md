# Roadmap

Phase 1 MVP
Phase 2 AI modules
Phase 3 RAG
Phase 4 Multi-agent
