# Low Level Design

Define modules, interfaces, DTOs, repositories, services, middleware, providers.
