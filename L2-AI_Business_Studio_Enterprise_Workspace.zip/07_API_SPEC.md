# API Specification

POST /register
POST /login
POST /generate
GET /history
