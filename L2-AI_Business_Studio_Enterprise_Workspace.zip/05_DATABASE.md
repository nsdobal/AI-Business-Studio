# Database Design

Entities:
Users, Roles, UserApiKeys, ApiProviders, AIModels, Prompts, IdeaRequests, IdeaResponses, ConversationHistory, AuditLogs.
