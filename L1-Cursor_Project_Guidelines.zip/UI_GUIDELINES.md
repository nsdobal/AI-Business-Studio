# UI_GUIDELINES.md

# Product Design Vision

The UI should resemble a premium commercial SaaS.

## Design Goals

- Minimal
- Modern
- Premium
- Spacious
- Responsive
- Accessible

## Layout

- Sticky top navigation
- Collapsible sidebar
- Card-based content
- Rounded corners
- Subtle shadows
- Smooth transitions

## Theme

- Light
- Dark
- System detection

## Components

Use reusable:
- Buttons
- Cards
- Dialogs
- Inputs
- Tables
- Alerts
- Snackbars
- Skeleton loaders

## UX

Every async action must provide:
- Loading state
- Success feedback
- Error feedback
- Empty state

Avoid clutter.
Prefer whitespace over dense layouts.
