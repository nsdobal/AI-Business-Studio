# AGENTS.md

# AI Business Studio

## Transform Ideas into Businesses with AI

## Mission
Build a production-quality AI SaaS application using enterprise architecture, modern UI/UX, secure coding practices, and Azure-ready deployment. This project should resemble a commercial SaaS platform rather than a tutorial.

---

# Product Vision

AI Business Studio is an extensible platform that helps users transform ideas into businesses using AI.

Version 1 will fully implement the **Business Idea Generator** while the architecture must support future modules:

- Market Research
- SWOT Analysis
- Competitor Analysis
- Business Model Canvas
- Marketing Strategy
- Investor Pitch
- Execution Roadmap
- AI Agents
- RAG
- Vector Databases
- MCP
- File Analysis

Design for extension without major refactoring.

---

# Technology Stack

## Frontend

- React 19
- TypeScript
- Vite
- Material UI
- React Router
- Axios
- React Hook Form
- Zod
- Context API
- React Markdown
- Lucide Icons

## Backend

- Python 3.13
- FastAPI
- SQLAlchemy
- Alembic
- Pydantic
- JWT
- bcrypt
- Dependency Injection

## Database

Azure SQL Database

## Deployment

- Azure VM
- Docker
- Docker Compose
- Nginx
- HTTPS Ready

---

# Architecture

Use Clean Architecture.

Presentation

↓

API

↓

Service

↓

Repository

↓

Database

Rules

- No business logic inside controllers.
- Use repository pattern.
- Use dependency injection.
- Keep modules loosely coupled.
- Follow SOLID, DRY and KISS.

---

# Folder Structure

Create:

frontend/
backend/
database/
deployment/
docker/
docs/
scripts/
tests/
postman/
nginx/
.github/

Frontend:

src/
components/
layouts/
pages/
hooks/
contexts/
services/
theme/
types/
utils/
assets/
constants/

Backend:

app/
api/
core/
config/
database/
models/
schemas/
repositories/
services/
providers/
security/
middleware/
routers/
dependencies/
prompts/
utils/

---

# Premium UI / UX

The application MUST look like a premium commercial SaaS.

Reference quality:

- ChatGPT
- Claude
- Perplexity
- Linear
- Notion AI
- Stripe Dashboard
- Vercel Dashboard

Do not copy their design.

Instead emulate:

- Professional spacing
- Clean typography
- Elegant cards
- Responsive layouts
- Modern animations
- Minimal visual noise

Requirements

- Light theme
- Dark theme
- System theme detection
- Responsive
- Accessible
- Fast
- Reusable components
- No generic admin template appearance

---

# Pages

Landing Page

Dashboard

Business Generator

History

Prompt Library

AI Providers

Profile

Settings

Admin

---

# Landing Page

Professional hero section.

Headline:

Transform Ideas into Businesses with AI

Buttons

- Get Started
- Login

Include feature cards and responsive layout.

---

# Authentication

Implement

- Register
- Login
- Logout
- JWT
- Refresh Token
- Remember Me
- Forgot Password placeholder
- Roles (Admin/User)

Passwords must be hashed using bcrypt.

---

# AI Providers

Architecture must support:

- OpenAI
- Azure OpenAI
- Anthropic
- Gemini
- Groq
- OpenRouter
- Ollama

Implement provider abstraction.

---

# API Keys

Store per-user API keys.

Requirements

- AES-256 encryption
- Encryption key from environment variables
- Never store plaintext
- Never expose plaintext
- Display ******** after save
- Decrypt only in memory

---

# Business Generator

Input

Large prompt textarea

Dropdowns

- Provider
- Model
- Generator Type

Buttons

- Generate
- Regenerate
- Clear
- Copy
- Export

Streaming response.

Render output as individual cards:

- Business Name
- Tagline
- Problem
- Solution
- Target Audience
- Revenue Model
- Pricing
- MVP
- Technology Stack
- Marketing
- SWOT
- Risks
- Roadmap
- Investor Pitch

Support Markdown.

---

# History

Store:

- Prompt
- Response
- Provider
- Model
- Tokens
- Estimated Cost
- Timestamp

Support search, filters, delete, export.

---

# Database Tables

Users
Roles
UserApiKeys
ApiProviders
AIModels
Prompts
IdeaRequests
IdeaResponses
ConversationHistory
AuditLogs
ApplicationSettings

Generate SQLAlchemy models and Alembic migrations.

---

# API

Authentication

POST /register
POST /login
POST /refresh
POST /logout

Profile

GET /profile
PUT /profile

Providers

GET /providers
GET /models
POST /apikey
PUT /apikey
DELETE /apikey

AI

POST /generate
GET /history
GET /history/{id}
DELETE /history/{id}

Admin

GET /users
GET /audit

---

# Security

Implement:

- JWT
- Refresh Tokens
- AES-256
- bcrypt
- Rate limiting
- Input validation
- SQL Injection prevention
- XSS protection
- CORS
- Secure headers
- Structured logging
- Audit logging

Never log secrets.

---

# Documentation

Generate:

README.md
Architecture.md
Database.md
API.md
Deployment.md
Security.md

---

# Testing

Generate

- Unit tests
- API tests
- Authentication tests
- Repository tests

---

# Deployment

Generate:

- Frontend Dockerfile
- Backend Dockerfile
- docker-compose.yml
- Nginx configuration
- Azure VM deployment guide
- Azure SQL deployment guide
- Production checklist

---

# Cursor Workflow (Trial Optimized)

Read this file completely before generating code.

Generate the project in ONLY THREE phases.

## Phase 1 — Foundation

Generate:

- Folder structure
- Configuration
- Frontend foundation
- Backend foundation
- Theme
- Layout
- Landing page
- Dashboard layout
- Authentication foundation
- Database models
- Docker foundation

Do NOT implement AI providers yet.

Deliver a working foundation.

## Phase 2 — Core Features

Generate:

- Provider abstraction
- OpenAI integration
- Encrypted API key management
- Business Generator
- Streaming responses
- Markdown rendering
- History
- Frontend integration
- Backend integration

Leave hooks for future providers.

## Phase 3 — Production Readiness

Generate:

- Admin module
- Tests
- Documentation
- Azure deployment
- Performance optimization
- Security review
- UI polish
- Final refactoring

Remove duplicate code.

Prepare the application for production deployment.

---

# Coding Standards

- SOLID
- DRY
- KISS
- Repository Pattern
- Service Pattern
- Dependency Injection
- Type hints
- Docstrings
- Meaningful naming
- Reusable components

Never generate tutorial-quality code.

---

# Final Quality

Assume the code will be reviewed by Principal Engineers.

Every implementation should prioritize:

- Maintainability
- Scalability
- Security
- Performance
- Readability
- Extensibility

If there is a conflict between speed and quality, choose the production-quality approach.
