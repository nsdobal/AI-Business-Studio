# ARCHITECTURE.md

# Enterprise Architecture

## Principles
- Clean Architecture
- SOLID
- DRY
- KISS
- Separation of Concerns
- Dependency Injection
- Repository + Service Pattern

## Layers

Frontend (React)
↓
FastAPI Controllers
↓
Services (Business Logic)
↓
Repositories (Data Access)
↓
Azure SQL Database

## Rules

- Controllers never contain business logic.
- Services never know HTTP details.
- Repositories never contain business logic.
- Every feature is modular.
- Prefer interfaces/abstractions for AI providers.
- Configuration comes only from environment variables.
- API keys are encrypted at rest.
- Never duplicate code.

## Future Expansion

Architecture must support:
- RAG
- MCP
- AI Agents
- Azure AI Foundry
- Vector Databases
- File Upload
- Background Jobs
- Notifications
